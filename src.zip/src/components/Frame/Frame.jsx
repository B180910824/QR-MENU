export const Frame = ({ property1, frameClassName, photo, name, price }) => {
  return (
    <div className={`frame ${property1}`}>
      {/* Set the background image using the photo prop */}
      <div className="div" style={{ backgroundImage: `url(${photo})` }} />
      <div className={`div-2 ${frameClassName}`}>
        <div className="div-wrapper">
          {/* Display the name from the prop */}
          <div className="text-wrapper">{name}</div>
        </div>
        {/* Display the price from the prop */}
        <div className="text-wrapper-2">{price}</div>
      </div>
    </div>
  );
};

Frame.propTypes = {
  property1: PropTypes.oneOf(["variant-2", "default"]),
  // Add prop validations for the new props
  photo: PropTypes.string,
  name: PropTypes.string,
  price: PropTypes.string,
};
