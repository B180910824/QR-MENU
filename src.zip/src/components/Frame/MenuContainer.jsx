import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Frame } from './Frame';

const MenuContainer = () => {
  const [menuItem, setMenuItem] = useState({ name: '', price: '', photo: '' });

  useEffect(() => {
    // Replace with your actual API endpoint
    const apiURL = 'http://localhost:8000/api/product/buuz';

    const fetchData = async () => {
      try {
        const response = await axios.get(apiURL);
        // Assuming the response has data with the name, price and photo
        setMenuItem({
          name: response.data.name,
          price: response.data.price,
          photo: response.data.photo,
        });
      } catch (error) {
        console.error('Error fetching data:', error);
        // Handle error or set default values
      }
    };

    fetchData();
  }, []);

  return (
    <Frame
      property1="default" // or "variant-2", based on your API data or state
      frameClassName=""
      // Add additional props as needed, for example:
      // photo={menuItem.photo}
      // name={menuItem.name}
      // price={menuItem.price}
    />
  );
};

export default MenuContainer;
