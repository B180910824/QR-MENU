export { Mongolia2 } from "./Mongolia2";
