import React from "react";
import ReactDOMClient from "react-dom/client";
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import { Screen } from "./screens/Screen";
import ProductDetail from "./screens/ProductDetail"; // Assuming you have or will create this component

import "../global.css";
import "../styleguide.css";

const app = document.getElementById("app");
const root = ReactDOMClient.createRoot(app);

root.render(
  <Router>
    <Switch>
      <Route path="/" exact component={Screen} />
      <Route path="/product/:id" component={ProductDetail} />
      {/* Add more routes as needed */}
    </Switch>
  </Router>
);
