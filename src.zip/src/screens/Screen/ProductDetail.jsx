import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';

const ProductDetail = () => {
  const { id } = useParams();
  const [product, setProduct] = useState(null);

  useEffect(() => {
    // Fetch product details from your API using the id
    const fetchProductDetails = async () => {
      const response = await fetch(`http://202.179.6.26:8000/api/product/detail/${id}`);
      const data = await response.json();
      setProduct(data);
    };

    fetchProductDetails();
  }, [id]);

  if (!product) {
    return <div>Loading...</div>;
  }

  return (
    <div>
      {/* Render product details */}
      <h1>{product.name}</h1>
      {/* Add more product details here */}
    </div>
  );
};

export default ProductDetail;
